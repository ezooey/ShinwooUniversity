 (function ($) {
 "use strict";
 
	$('#menu1').metisMenu();

})(jQuery); 
 
 
 